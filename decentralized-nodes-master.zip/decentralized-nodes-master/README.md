# decentralized-nodes
Proof of concept of decentralized nodes
### Genesis block hash
```kvdISoqbRO1CQkKLoCjg/pL3SEqKm0TtQkJCi6Ao4P4=```
