<?php

/*
* Include the necessarysettings and libraries
*/
$config = include 'config.php';
include './vendor/autoload.php';
include 'functions.php';